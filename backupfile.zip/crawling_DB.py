import requests, time, datetime
from bs4 import BeautifulSoup
import pymysql


class calltransaction_transaction_RT():
    # while(1):
    #    time.sleep(60)
        html = requests.get('https://www.naver.com/').text
        soup = BeautifulSoup(html, 'html.parser')
        now = datetime.datetime.now()
        title_list = soup.select('.PM_CL_realtimeKeyword_rolling span[class*=ah_k]')
        Machined_title_list = list()
        for idx, title in enumerate(title_list, 1):
            Machined_title_list.append(title.text)

        print(Machined_title_list)

        nowDate = now.strftime('%Y%m%d')
        #nowDate = 20190120
        nowTime = now.strftime('%H%M')


        # MySQL Connection 연결
        conn = pymysql.connect(host='127.0.0.1', user='admin', password='rootroot',
                               db='db_crawling', charset='utf8')

        # Connection 으로부터 Cursor 생성
        #curs = conn.cursor()
        curs = conn.cursor(pymysql.cursors.DictCursor)

        b = 20
        

        #현재 1등 데이터가 TOP20 테이블에 이미 존재하고 있는지 검사
        check = Machined_title_list[0]
        sql = "select * from crawling_receive_google_data where key1=%s and G_Word=%s"
        curs.execute(sql, (nowDate,check))
        check_resuit = curs.fetchall()
        if not check_resuit:
            print("Warning!!!")

        #가져온 20개의 키워드 insert, update
        for a in Machined_title_list:
            #orgin score call
            
            #검색된 단어의 점수가 존재하는 지, 몇점인지 확인한다.
            sql = "select G_Rating from crawling_receive_google_data where key1=%s and G_Word=%s"
            curs.execute(sql,(nowDate,a))
            num = curs.fetchall()

            if num:
                print("already exist")
                for x in num:
                    d = list(x.values())
                    k = int(d[0])
                    k = k+b
		#만약 a[0]값이 crawling_receive_google_data에 없으며 주의 메세지 출력

                    sql = "UPDATE crawling_receive_google_data SET G_Rating=%s WHERE G_Word=%s"
		    #### 전날 날짜에 업데이트 하게되는 문제
                    curs.execute(sql, (k,a))
                    rows = curs.fetchall()
                    conn.commit()

            else : 
                
                print("New Input")
                sql = "INSERT INTO crawling_receive_google_data (key1,G_Word,G_Rating) VALUES(%s,%s,%s)"
                #sql = "select * from crawling_receive_google_data where key1=%s and G_Word='abc' and G_Rating=%s" % (nowDate, b)
                curs.execute(sql,(nowDate,a,b))
                rows = curs.fetchall()
                conn.commit()

            b = b - 1

        sql = "select G_Word from crawling_receive_google_data where key1=%s" % (nowDate)
        curs.execute(sql)
        rows = curs.fetchall()
        print(rows)

        conn.close()