import requests, time, datetime
from bs4 import BeautifulSoup
import pymysql


class calltransaction_transaction_RT():
    # while(1):
    #    time.sleep(60)
        html = requests.get('https://www.naver.com/').text
        soup = BeautifulSoup(html, 'html.parser')
        now = datetime.datetime.now()
        title_list = soup.select('.PM_CL_realtimeKeyword_rolling span[class*=ah_k]')
        Machined_title_list = list()
        for idx, title in enumerate(title_list, 1):
            Machined_title_list.append(title.text)

        print(Machined_title_list)

        nowDate = now.strftime('%Y%m%d')
        nowTime = now.strftime('%H%M')

        params = {
        "_date": nowDate,
        "_time": nowTime,
        "_value": json.dumps(Machined_title_list)
        }

        transaction = CallTransactionBuilder() \
        .from_(_keystore_address) \
        .to(_score_address) \
        .step_limit(10_000_000) \
        .nid(3) \
        .nonce(100) \
        .method("transaction_RT") \
        .params(params) \
        .build()
        print(nowDate, nowTime)
        signed_transaction = SignedTransaction(transaction, wallet)
        tx_hash = icon_service.send_transaction(signed_transaction)
        print(tx_hash)
        time.sleep(10)
        tx_result = icon_service.get_transaction_result(tx_hash)
        print(tx_result['status'])

        # MySQL Connection 연결
        conn = pymysql.connect(host='127.0.0.1', user='admin', password='rootroot',
                               db='db_crawling', charset='utf8')

        # Connection 으로부터 Cursor 생성
        #curs = conn.cursor()
        curs = conn.cursor(pymysql.cursors.DictCursor)

        b = 20
        for a in Machined_title_list:
            #orgin score call

            sql = "select G_Rating from crawling_receive_google_data where G_Word=%s"
            curs.execute(sql,a)
            num = curs.fetchall()
            if num:
                for x in num:
                    d = list(x.values())
                    k = int(d[0])
                    k = k+b

                #sql = "INSERT INTO crawling_receive_google_data (Key1,G_Word,G_Rating) VALUES(%s,%s,%s) ON DUPLICATE KEY UPDATE G_Word=%s, G_Rating=%s"
                sql = "UPDATE crawling_receive_google_data SET G_Rating=%s WHERE G_Word=%s"
                curs.execute(sql, (k,a))
                rows = curs.fetchall()
                conn.commit()

            else :
                sql = "INSERT INTO crawling_receive_google_data (Key1,G_Word,G_Rating) VALUES(%s,%s,%s)"
                #sql = "select * from crawling_receive_google_data where Key1=%s and G_Word='abc' and G_Rating=%s" % (nowDate, b)
                curs.execute(sql,(nowDate,a,b))
                rows = curs.fetchall()
                conn.commit()

            b = b - 1

        sql = "select G_Word from crawling_receive_google_data where Key1=20190220"
        curs.execute(sql)
        rows = curs.fetchall()
        print(rows)

        conn.close()