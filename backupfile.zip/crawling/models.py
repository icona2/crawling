from django.db import models
from django_pandas.managers import DataFrameManager

class Post(models.Model):
    date = models.IntegerField(default=0)
    date2 = models.IntegerField(default=0)
    word = models.CharField(max_length=200)
    
    def publish(self):
        self.save()
        
    def __str__(self):
        return self.word
        
class Post2(models.Model) :
    date1 = models.CharField(max_length=200)
    date2 = models.CharField(max_length=200)
    word = models.CharField(max_length=200)  
    
    def publish(self):
        self.save()
        
    def __str__(self):
        return self.word


class Receive_Google_Data(models.Model) :
    key1 = models.IntegerField(default=0)
    G_Word = models.CharField(max_length=200)
    G_Rating = models.IntegerField(default=0) 

    objects = DataFrameManager() 
    
    def publish(self):
        self.save()
        
    def __str__(self):
        return self.G_Word