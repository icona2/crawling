from .models import Post, Post2, Receive_Google_Data
from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import Max
from django_pandas.io import read_frame
from django_pandas.managers import DataFrameManager
from IPython.display import display

def index(request):
    userdate = request.GET.get("userdate")
    usertime = request.GET.get("usertime")

    #===========TEST CODE=============
    #if userdate == None:
    #    return render(request, 'crawling/realtime.html')

    #else:
    #    return HttpResponse(userdate)

    
    if userdate == None or usertime == None:
        userdate = Post.objects.last().date
        posts = list(Post.objects.filter(date=userdate))
        return render(request, 'crawling/realtime.html', {'posts' : posts}) 

    elif int(userdate) >= 20190200 and int(userdate) <= 20200200  :
        posts = list(Post.objects.filter(date=userdate))
        return render(request, 'crawling/realtime.html', {'posts' : posts})    
    else :
        posts = str(Post.objects.last())
        #return render(request, 'crawling/realtime, {'posts' : posts})    
        return HttpResponse("No data" )



def index2(request):
    userdate = request.GET.get("userdate")
    usertime = request.GET.get("usertime")

    if userdate == None or usertime == None:
        userdate = Post.objects.last().date
        posts = list(Post.objects.filter(date=userdate))
        return render(request, 'crawling/realtime_google.html', {'posts' : posts}) 

    elif int(userdate) >= 20190200 and int(userdate) <= 20200200  :
        posts = list(Post.objects.filter(date=userdate))
        return render(request, 'crawling/realtime_google.html', {'posts' : posts})    
    else :
        posts = str(Post.objects.last())
        #return render(request, 'crawling/realtime_google.html', {'posts' : posts})    
        return HttpResponse("No data" )

def top(request):
        userdate = request.GET.get("userdate")
        if userdate == None :
            userdate = Receive_Google_Data.objects.last().key1
            temp_posts = list(Receive_Google_Data.objects.filter(key1=userdate).order_by('-G_Rating'))
            POSTS = TEMP_POSTS[0:20]

        elif int(userdate) >= 20190200 and int(userdate) <=20200200 :
            temp_posts = list(Receive_Google_Data.objects.filter(key1=userdate).order_by('-G_Rating'))
            posts = temp_posts[0:20]

        else :
            return render(request, 'crawling/realtime_Top20.html')

        return render(request, 'crawling/realtime_Top20.html', {'posts': posts})

def top2(request):
        posts = list(Receive_Google_Data.objects.filter(G_Rating=20190220))
        return render(request, 'crawling/realtime_Top20_google.html', {'posts': posts})

def input(request):
    return render(request, 'crawling/index.html')


def checkTop1(request):
        userdate = request.GET.get("userdate")
        if userdate == None :
            userdate = Receive_Google_Data.objects.last().key1
            temp_posts = list(Receive_Google_Data.objects.filter(key1=userdate).order_by('-G_Rating'))
            POSTS = TEMP_POSTS[0:20]

        elif int(userdate) >= 20190200 and int(userdate) <=20200200 :
            temp_posts = list(Receive_Google_Data.objects.filter(key1=userdate).order_by('-G_Rating'))
            posts = temp_posts[0:20]

        else :
            return render(request, 'crawling/realtime_Top20.html')

        return render(request, 'crawling/realtime_Top20.html', {'posts': posts})



def chart(request):
         temp_posts = Receive_Google_Data.objects.filter(key1=20190220).order_by('-G_Rating')
         posts = read_frame(temp_posts,fieldnames=['key1', 'G_Word','G_Rating'])
         
         #posts = temp_posts.to_dataframe(['key1', 'G_Rating'], index='G_Word')
         a = posts.to_html
         return HttpResponse(a)

         #qs = Product.objects.all()
         #df = read_frame(qs)
         #html= df.to_html
         


	 #return display(temp_posts.to_dataframe(['key1', 'G_Rating'], index='G_Word'))

	 #table_rows = temp_posts[0:20]
    	 #return render(request, 'crawling/chart.html',{'posts': posts})


